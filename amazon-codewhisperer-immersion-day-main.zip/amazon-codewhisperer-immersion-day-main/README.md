# CodeWhisperer Workshop

This repository includes sample code used in the CodeWhisperer Immersion Day. 