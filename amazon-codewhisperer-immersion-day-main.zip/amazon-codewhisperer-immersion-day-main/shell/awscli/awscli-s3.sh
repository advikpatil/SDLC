#!/bin/bash
#check the current folder path

#access the folder mythical-misfits inside /etc

#sync local folder to a S3 bucket named mythical-misfits

#sync deleted files from local to S3 bucket
