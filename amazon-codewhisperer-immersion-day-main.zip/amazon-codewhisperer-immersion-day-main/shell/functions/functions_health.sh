#!/bin/bash
#create a function to check if the file test.txt exists

       #check if the file contains the string "Healthy"
 
#call the function check_file   
