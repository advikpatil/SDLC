#!/bin/bash
#update yum

#install httpd

#install php

#create a hello_world.php

#start webserver

#enable webserver

#check status

#check version

#check logs
