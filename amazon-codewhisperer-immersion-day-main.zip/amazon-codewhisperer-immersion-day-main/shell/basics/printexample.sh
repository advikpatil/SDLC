#!/bin/bash
#print the number of files in the current directory
