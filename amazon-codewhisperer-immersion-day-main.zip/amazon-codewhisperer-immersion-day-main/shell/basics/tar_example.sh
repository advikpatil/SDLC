#!/bin/bash
tar -x