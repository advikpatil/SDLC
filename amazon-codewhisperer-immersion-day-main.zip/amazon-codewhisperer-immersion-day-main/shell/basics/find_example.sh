#!/bin/bash
touch test.txt
find . -n