﻿namespace Deals
{
    public partial class DealsApi
    {
        public class APIResponse
        {
            public string ContentType { get; set; } = string.Empty;
            public string Content { get; set; } = string.Empty;
        }
    }
}
