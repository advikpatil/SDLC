package com.amazon.aws.basics;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

//write a junit for Calculator class methods
