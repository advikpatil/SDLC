package com.amazon.aws.basics;

public class CSVParser {   
    //Parse a csv string and print the results
    //columns include id,name and status    
}