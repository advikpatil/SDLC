package com.amazon.aws.basics;

//import required packages for creating an s3 bucket using software.amazon.awssdk

public class AWSExample {
    // create s3 bucket
    
}