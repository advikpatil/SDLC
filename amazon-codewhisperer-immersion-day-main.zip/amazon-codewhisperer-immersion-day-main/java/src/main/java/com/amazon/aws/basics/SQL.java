package com.amazon.aws.basics;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.SQLException;

public class SQL {

   //connect to a mysql database
   
   
}
