package com.amazon.aws.basics;

//program to do binary search