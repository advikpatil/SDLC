# Sample table schema:
#CREATE TABLE Contacts ( 
#  ID int, 
#  LastName varchar(255), 
#  FirstName varchar(255), 
#  Address varchar(255), 
#  City varchar(255), 
#  State varchar(255), 
#  ZipCode varchar(5), 
#); 
#





