import re
# function to verify email address