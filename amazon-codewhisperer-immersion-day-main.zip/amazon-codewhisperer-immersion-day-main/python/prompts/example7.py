from unittest import TestCase

# Function to sum two numbers
def sum(x, y):
    return x + y

class TestSum(TestCase):
    # test the sum method with integers
