""" 
Function that takes a list that contains some numbers and strings, format them 
into a string in which the numbers are prepended with a '#' and the strings 
are wrapped in double quotes
"""
