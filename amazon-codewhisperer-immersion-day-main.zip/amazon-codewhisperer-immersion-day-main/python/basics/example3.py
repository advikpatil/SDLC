# Parse a CSV string of songs and return a list of dictionaries
# Fields include artist, album, title and year
# Ignore lines starting with #