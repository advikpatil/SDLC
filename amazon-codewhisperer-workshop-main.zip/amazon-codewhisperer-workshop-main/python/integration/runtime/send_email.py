from xml.etree.ElementTree import Element, ElementTree, tostring
import requests

# 1.) Convert JSON string to XML string

# 2.) Send XML string with HTTP POST

# <<Amazon CodeWhisperer generated code goes here>>

def handler(event, context):

    # call method 1.) with var "event" to convert json to xml

    # call method 2.) to post xml

    return {
        'statusCode': 200,
        "message": "Success!"
    }
